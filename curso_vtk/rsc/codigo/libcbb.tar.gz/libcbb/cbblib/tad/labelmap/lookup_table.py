# -*- coding: utf-8 -*-
'''
Created on 02/12/2009

@author: jmorales
'''

import vtk

class LookupTable(object):
    '''
    classdocs
    '''
    def __init__(self, description=None): 
        ''' Build a LookupTable from a description list
        @param description: {segment : (name,r, g, b)}
                            0 <= r,g,b <= 255
        '''
        self.lut = {}

        if description:
            self.lut = description
        else:
            self.add_item('Asymmetric', 0, 255, 0, 1)
            self.add_item('Symmetric', 255, 0, 0, 2)


    def add_item(self, name, r, g, b, segment=None):
        ''' Add a label. 0 <= r,g,b <= 255'''
        if not segment:
            segment = max(self.lut.keys()) + 1 if self.lut else 1

        self.lut[segment] = (name, r, g, b)

    
    def get_as_vtkLookupTable(self):
        ''' Build a LookupTable from a description list 
        @return: vtkLookupTable
        '''
        vtklut = vtk.vtkLookupTable()
        #vtklut.SetNumberOfColors(len(self.lut)+1)  # Plus Background 
        vtklut.SetNumberOfColors(max(self.lut.keys())+1)  # Plus Background 
        #vtklut.SetTableRange(0, len(self.lut))
        vtklut.SetTableRange(0, max(self.lut.keys()))
        vtklut.Build()
        
        vtklut.SetTableValue(0, 0, 0, 0, 0) # Transparent Background
        for segment in self.lut:
            _name, r, g, b = self.lut[segment]
            vtklut.SetTableValue(segment, r/255.0, g/255.0, b/255.0, 1)
        return vtklut
        
    def get_as_vtkColorTransferFunction(self):
        ''' Build  a vtkColorTransferFunction from a description list 
        @return vtkColorTransferFunction
        '''
        colorlut = vtk.vtkColorTransferFunction()
        colorlut.AddRGBPoint(0, 0.0, 0.0, 0.0) # Transparent Background
        for segment in self.lut:
            _name, r, g, b = self.lut[segment]
            colorlut.AddRGBPoint(segment, r/255.0, g/255.0, b/255.0)
        return colorlut
        
    def get_as_description(self):
        return self.lut

