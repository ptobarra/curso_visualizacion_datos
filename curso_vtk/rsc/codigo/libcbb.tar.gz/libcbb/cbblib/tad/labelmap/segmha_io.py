# -*- coding: utf-8 -*-
'''
Created on 04/10/2010

@author: jmorales
'''

import re
import itk 
import os
import shutil
import abc
import segmentation as segmentation_pkg
import lookup_table as lookup_table_pkg
import multiprocessing

class SegmentationMetaImageReader(object):
     
    def read(self, file_name):

        reader = itk.ImageFileReader[segmentation_pkg.Segmentation.export_image_type].New()
        reader.SetFileName(file_name)
        reader.SetImageIO(itk.MetaImageIO.New())
        reader.Update()
        
        file = open(file_name, 'rb') # Read in Win binary mode: Windows EOF are in the raw data
        text = file.read()
        
        # Create the Lookup Table
        lut = self.read_lut(text)
        segment_table, select_table = self.read_tables(text)
        inclusive_margins, exclusive_margins = self.read_counting_brick(text)
        
        file.close()
        
        segmentation = segmentation_pkg.Segmentation()
        segmentation.import_image_as_labelmap(reader.GetOutput())
        segmentation.segment_table = segment_table
        segmentation.select_table = select_table
        segmentation.set_ubiased_brick_margins(inclusive_margins, exclusive_margins)

        return segmentation, lut

    def read_tables(self, text):
        patern = re.compile("\s*[^#]\s*"
                            "Object\s*:\s*"
                            "label\s*=\s*(\d+)\s*"
                            "segment\s*=\s*(\d+)\s*"
                            "selected\s*=\s*(\d+)")
        matches = patern.findall(text)
        segment_table = {}
        select_table = {}
        for match in matches:
            label, segment, selected = match
            segment_table[int(label)] = int(segment)
            select_table[int(label)] = bool(int(selected))
        return segment_table, select_table

    def read_counting_brick(self, text):
        #Counting Brick: inclusive=%s exclusive=%s"
        patern = re.compile("\s*[^#]\s*"
                    "Counting Brick\s*:\s*"
                    "inclusive\s*=\s*(\[\d+, \d+, \d+\])\s*"
                    "exclusive\s*=\s*(\[\d+, \d+, \d+\])")
        matches = patern.findall(text)
        inclusive_margins = eval(matches[0][0])
        exclusive_margins = eval(matches[0][1])
        return inclusive_margins, exclusive_margins
        
        
    def read_lut(self, text):
        #Search Label definitions
        patern_labels = re.compile("\s*[^#]\s*"
                                   "Segment\s*:\s*"
                                   "name\s*=\s*\"(\w+[\w|\s]*)\"\s*"
                                   "value\s*=\s*(\d+)\s*"
                                   "color\s*=\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)")
        matches = patern_labels.findall(text)
        description = {}
        for match in matches:
            name, value, r, g, b = match
            description[int(value)] = (name, int(r), int(g), int(b))
        return lookup_table_pkg.LookupTable(description)


class SegmentationWriter(object):
    
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod    
    def write(self, file_name, segmentation, lookup_table ):
        ''' Writes the segmentation '''

    def write_tables(self, file, segmentation):
        file.write("\n")
        for label in segmentation.segment_table:
            segment = segmentation.segment_table[label]
            select = segmentation.select_table[label]
            file.write("\nObject: label=%d segment=%d selected=%d" % (label, segment, int(select)))

    def write_counting_brick(self, file, segmentation):
        file.write("\n")
        file.write("\nCounting Brick: inclusive=%s exclusive=%s" % (segmentation.inclusive_margins, 
                                                                    segmentation.exclusive_margins ))
        
    def write_lut(self, file, lut):
        file.write("\n")
        description = lut.get_as_description()
        for value in description:
            name, r, g, b = description[value]
            file.write("\nSegment: name=\"%s\" value=%d color= %d, %d, %d" % (name, value, r, g, b))


class SegmentationMetaImageWriter(SegmentationWriter):

    def background_write(self, file_name, segmentation, lookup_table):
        ''' The writing is made by a fork process. The process is not joined 
        becasue the aim is not blocking the tool. When the process finish becomes
        zombie until the next process is created, the call for creating a process
        joins all the zombie processes.        
        '''
        p = multiprocessing.Process(target=self.write, args=(file_name, segmentation, lookup_table))
        p.start()
        
    
    def write(self, file_name, segmentation, lookup_table):
        mha_file = os.path.splitext(file_name)[0]+"-segmha-temp.mha"
        # NOTE: itk.ImageFileWriter writes all-in-one files if the extension is mha 
        if os.path.isfile(mha_file):
            raise Exception("The file %s must be move or renamed" % mha_file)
        labelmap = segmentation.export_labelmap_as_image()
        writer = itk.ImageFileWriter[segmentation_pkg.Segmentation.export_image_type].New()
        writer.SetInput(labelmap)
        writer.SetFileName(mha_file)
        writer.UseCompressionOn()
        writer.Write()
        
        shutil.move(mha_file, file_name)
        
        file = open(file_name, 'a') # Write at the end
        self.write_tables(file, segmentation)
        self.write_counting_brick(file, segmentation)
        self.write_lut(file, lookup_table)
        file.close()

class SegmentationTiffWriter(SegmentationWriter):
    def write(self, file_name, segmentation, lookup_table):
        meta_info_file = os.path.splitext(file_name)[0]+"-meta_info.txt"
        # NOTE: Because the meta_info file is not explicitly indicated should not be overwritten 
        if os.path.isfile(meta_info_file):
            raise Exception("The file %s must be move or renamed" % meta_info_file)
        labelmap = segmentation.export_labelmap_as_image()
        writer = itk.ImageFileWriter[segmentation_pkg.Segmentation.export_image_type].New()
        writer.SetInput(labelmap)
        writer.SetFileName(file_name)
        #writer.UseCompressionOn()
        writer.Write()
        
        file = open(meta_info_file, 'w')
        self.write_tables(file, segmentation)
        self.write_counting_brick(file, segmentation)
        self.write_lut(file, lookup_table)
        file.close()