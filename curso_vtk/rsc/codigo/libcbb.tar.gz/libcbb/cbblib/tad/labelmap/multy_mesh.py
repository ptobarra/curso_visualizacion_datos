'''
Created on 12/02/2012

@author: crispamares
'''
import itk
import vtk


class MultyMeshFilter(object):
    ''' This class creates a set of actors one per label object in the segmentation'''
    
    def __init__(self, segmentation, lut):
        '''
        labelmap = 
        lut = LookupTable
        '''
        self.segmentation = segmentation
        self.lut = lut

        self.actors = {}

    def update_labelmap(self, labelmap):
        self.labelmap = labelmap

    def update_lut(self, lut):
        self.lut = lut
        
    def compute_actors(self):
        labels = self.segmentation.get_labels()
        image_type = itk.Image[itk.US, 3]
        
        lut = self.lut.get_as_description()
        
        for label in labels:
            label_object = self.segmentation.extract_object(label, crop=True)
                   
            itk_vtk_converter = itk.ImageToVTKImageFilter[image_type].New()
            itk_vtk_converter.SetInput(label_object)
            itk_vtk_converter.Update()
            vtk_image = itk_vtk_converter.GetOutput()

            threshold = vtk.vtkImageThreshold()
            threshold.SetInput(vtk_image)
            threshold.SetOutValue(0)
            threshold.SetInValue(255)
            #threshold.ThresholdByUpper(1)
            threshold.ThresholdBetween(label, label)
            threshold.ReleaseDataFlagOn()
            threshold.Update()

            contour = vtk.vtkMarchingCubes()
            contour.ComputeScalarsOff()
            contour.ComputeGradientsOff()
            contour.ComputeNormalsOff()
            contour.SetInput(threshold.GetOutput())
            contour.SetValue(0, 127.5)
            contour.ReleaseDataFlagOn()
            
            normals = vtk.vtkPolyDataNormals()
            normals.SetInput(contour.GetOutput())
            normals.SetFeatureAngle(60)
            normals.ReleaseDataFlagOn()
        
            mapper = vtk.vtkPolyDataMapper()
            mapper.SetInput(normals.GetOutput())
    
            actor = vtk.vtkActor()
            actor.SetMapper(mapper)
            
            segment = self.segmentation.segment_table[label]
            _name, r, g, b = lut[segment]
            
            actor.GetProperty().SetDiffuseColor(r/255.0, g/255.0, b/255.0)
            actor.GetProperty().SetSpecularPower(80)
            actor.GetProperty().SetSpecular(0.5)
            actor.GetProperty().SetDiffuse(1)
            
            self.actors[label] = actor
        return self.actors
