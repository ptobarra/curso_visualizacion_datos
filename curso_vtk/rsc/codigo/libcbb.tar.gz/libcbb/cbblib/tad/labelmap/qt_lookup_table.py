# -*- coding: utf-8 -*-
'''
Created on 04/10/2010

@author: jmorales
'''

from PyQt4 import QtGui

from lookup_table import LookupTable

        
class QTLookupTable(LookupTable):
    '''
    Mantains a QStandardItemModel syncronized  
    '''
    def __init__(self, description=None): 
        ''' Build a LookupTable from a description list
        @param description: {segment : (name,r, g, b)}
                            0 <= r,g,b <= 255
        '''
        self.model = QtGui.QStandardItemModel()
        self.actual_segment = 1
        self.lut = {}
        self.item_segment_table = []
        
        if description:
            self.lut = description
            for segment in self.lut:
                name, r, g, b = self.lut[segment]
                self._append_item_to_model(r, g, b, name, segment)
        else:
            self.add_item('Asymmetric', 0, 255, 0, 1)
            self.add_item('Symmetric', 255, 0, 0, 2)
    def set_actual_segment(self, index):
        self.actual_segment = self.item_segment_table[index]
    def add_item(self, name, r, g, b, segment=None):
        ''' Add a label. 0 <= r,g,b <= 255'''
        if not segment:
            segment = max(self.lut.keys()) + 1 if self.lut else 1
        self.lut[segment] = (name, r, g, b)
        self._append_item_to_model(r, g, b, name, segment)
    
    def remove_item(self, index):
        segment = self.get_segment(index)
        self.model.removeRow(index.row())
        del self.lut[segment]
        del self.item_segment_table[index.row()]
    def change_name_from_item(self, item):
        new_name = str(item.text())
        segment = self.item_segment_table[item.row()]
        name,r, g, b = self.lut[segment]
        self.lut[segment] = (new_name, r, g, b)
        return new_name != name
    def change_color(self, r, g, b, index):
        segment = self.item_segment_table[index.row()]
        name, _old_r, _old_g, _old_b = self.lut[segment]
        self.lut[segment] = (name, r, g, b)
        
        item = self.model.itemFromIndex(index)
        pixmap = QtGui.QPixmap(20,20)
        pixmap.fill(QtGui.QColor(r, g, b))
        icon = QtGui.QIcon()
        icon.addPixmap(pixmap)
        
        item.setIcon(icon)
    def _append_item_to_model(self, r, g, b, name, segment):
        ''' Add Item to the model ''' 
        item = QtGui.QStandardItem()
        
        
        pixmap = QtGui.QPixmap(20,20)
        pixmap.fill(QtGui.QColor(r, g, b))
        icon = QtGui.QIcon()
        icon.addPixmap(pixmap)
        
        item.setIcon(icon)
        item.setText(name)
        
        self.model.appendRow(item)
        
        self.item_segment_table.append(segment)
        
    
    def get_segment(self, index):
        return self.item_segment_table[index.row()]
        
