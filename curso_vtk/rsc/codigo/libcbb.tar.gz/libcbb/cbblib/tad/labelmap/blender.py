# -*- coding: utf-8 -*-
'''
Created on 23/09/2009

@author: jmorales
'''
import vtk, itk

class LabelMapBlender(object):
    ''' Blends a grey scale image with a labelmap. 
        The labelmap is colored using a LookupTable.
    '''
    def __init__(self):
        self.image = None
        self.labelmap = None
        self.lut = None
        
        self.opacity = 0.8
        self.labelmap_visibility = True
        
        self.lut_image = None
        self.imtc_grey = None
        self.imtc_image = None
        self.blender = None

        self.lut_image = vtk.vtkWindowLevelLookupTable()
        self.lut_image.SetWindow(255)
        self.lut_image.SetLevel(127.5)
        self.lut_image.SetRampToLinear()
        self.lut_image.Build()
        
        self.imtc_image = vtk.vtkImageMapToColors()
        self.imtc_image.SetInput(self.image)
        self.imtc_image.SetLookupTable(self.lut_image)
        
        self.imtc_label = vtk.vtkImageMapToColors()
        self.blender = vtk.vtkImageBlend()
        
    def set_image(self, vtkImageData):
        self.image = vtkImageData
        self.imtc_image.SetInput(self.image)

    def set_labelmap(self, vtkImageData):
        self.labelmap = vtkImageData
        self.imtc_label.SetInput(self.labelmap)

    def set_lut(self, vtkLookupTable):
        self.lut = vtkLookupTable
        self.imtc_label.SetLookupTable(self.lut)
        
    def set_opacity(self, opacity):
        ''' @param: opacity float between 0 - 1'''
        self.opacity = opacity
        if self.blender:
            self.blender.SetOpacity(1, self.opacity)
    
    def get_output(self):
        '''  Returns the output pipeline if image, labelmap and lut exists'''
        if self.labelmap_visibility and self.image and self.labelmap and self.lut:
            self._install_pipeline()
            return self.blender.GetOutput()
        else: 
            return self.imtc_image.GetOutput()
    
    def _install_pipeline(self):
        ''' Install the blender pipeline'''

        self.lut_image = vtk.vtkWindowLevelLookupTable()
        self.lut_image.SetWindow(255)
        self.lut_image.SetLevel(127.5)
        self.lut_image.SetRampToLinear()
        self.lut_image.Build()

        self.imtc_image = vtk.vtkImageMapToColors()
        self.imtc_image.SetInput(self.image)
        self.imtc_image.SetLookupTable(self.lut_image)
        
        self.imtc_label = vtk.vtkImageMapToColors()
        self.imtc_label.SetInput(self.labelmap)
        self.imtc_label.SetLookupTable(self.lut)

        self.blender = vtk.vtkImageBlend()
        self.blender.SetInput(0, self.imtc_image.GetOutput())
        self.blender.SetInput(1, self.imtc_label.GetOutput())
        self.blender.SetOpacity(1, self.opacity)
        
    def set_visible(self, visible):
        self.labelmap_visibility = visible
    
        