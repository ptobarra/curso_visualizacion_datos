'''
Created on 11/02/2012

@author: crispamares
'''

import abc

#This are all the shape attributes.
#TODO: Only a subset is needed. This must be chosen using a preferences From. 
#
#shape_attributes = ["Size","PhysicalSize", "RegionElongation", 
#                    "SizeRegionRatio", "Centroid", "Region", "SizeOnBorder",
#                    "PhysicalSizeOnBorder", "FeretDiameter", "BinaryPrincipalMoments",
#                    "BinaryPrincipalAxes", "BinaryElongation", "Perimeter", "Roundness",
#                    "EquivalentRadius", "EquivalentPerimeter", 
#                    "EquivalentEllipsoidSize", "BinaryFlatness"]
#statistics_attributes = ["Minimum", "Maximum", "Mean", "Sum", "Sigma", 
#                         "Variance", "Median", "MaximumIndex", "MinimumIndex",
#                         "CenterOfGravity", "PrincipalMoments","PrincipalAxes",
#                         "Kurtosis", "Skewness", "Elongation", "Histogram",
#                         "Flatness"]
REQUEST_ATTRIBUTES = ["Size","PhysicalSize", "Centroid", "Region", 
                      "BinaryPrincipalMoments", "BinaryPrincipalAxes",
                      "FeretDiameter", "EquivalentEllipsoidSize"]

class IDataFilter(object):
    ''' The main of those objects is to make complex values as vector o matrix in
    order to be useful in tabulate form.
      
    @ivar original: str
    @ivar new_values: [new_1, new_2, ...]
    @ivar spacing: [x,y,z] set by the DataViewFilter.__init__
    
    @requires: An implementation of each 'new' value. 
        * The method must be called get_[name_of_the_new_header].
        * Only one param "value": the original value needed to be filtered. 
     Por exmaple:
        def get_new_1(self, value):
    '''
    __metaclass__ = abc.ABCMeta
    
class DataFilter(object):

    def __init__(self, spacing):
        self.filters = [CentroidFilter(),
                   RegionFilter(),
                   BinaryPrincipalMomentsFilter(),
                   BinaryPrincipalAxesFilter(),
                   EquivalentEllipsoidSizeFilter()]
        
        self.filtered_attributes = {}
        for filter in self.filters:
            self.filtered_attributes[filter.original] = filter
            filter.spacing = spacing

    def filter_header(self, header):
        '''@return: the filtered header '''
        new_header = []
        for att_name in header:
            if self.filtered_attributes.has_key(att_name):
                new_header += self.filtered_attributes[att_name].new_values
            else:
                new_header.append(att_name)
        return new_header
    
    def filter_data(self, data):
        '''@return: The filtered data '''
        new_data = {}
        header = data.keys()
        for att_name in header:
            if self.filtered_attributes.has_key(att_name):
                filter = self.filtered_attributes[att_name]
                for new_value in filter.new_values:
                    new_data[new_value] = filter.__getattribute__("get_"+new_value)(data[att_name])
            else:
                new_data[att_name] = data[att_name] 
        return new_data




class CentroidFilter(IDataFilter):

    original = 'Centroid'
    new_values = ['Centroid_X',
                  'Centroid_Y',
                  'Centroid_Z']
    
    def get_Centroid_X (self, value):
        return value[0]
    def get_Centroid_Y (self, value):
        return value[1]
    def get_Centroid_Z (self, value):
        return value[2]
        
        
class RegionFilter(IDataFilter):

    original = 'Region'
    new_values = ['Region_X',
                  'Region_Y',
                  'Region_Z']
    
    def get_Region_X (self, value):
        return value.GetIndex(3) * self.spacing[0]
    def get_Region_Y (self, value):
        return value.GetIndex(4) * self.spacing[1]
    def get_Region_Z (self, value):
        return value.GetIndex(5) * self.spacing[2]


class BinaryPrincipalMomentsFilter(IDataFilter):

    original = 'BinaryPrincipalMoments'
    new_values = ['BinaryPrincipalMoments_X',
                  'BinaryPrincipalMoments_Y',
                  'BinaryPrincipalMoments_Z']
    
    def get_BinaryPrincipalMoments_X (self, value):
        return value[0]
    def get_BinaryPrincipalMoments_Y (self, value):
        return value[1]
    def get_BinaryPrincipalMoments_Z (self, value):
        return value[2]


class BinaryPrincipalAxesFilter(IDataFilter):

    original = 'BinaryPrincipalAxes'
    new_values = ['BinaryPrincipalAxes_0_0',
                  'BinaryPrincipalAxes_0_1',
                  'BinaryPrincipalAxes_0_2',
                  'BinaryPrincipalAxes_1_0',
                  'BinaryPrincipalAxes_1_1',
                  'BinaryPrincipalAxes_1_2',
                  'BinaryPrincipalAxes_2_0',
                  'BinaryPrincipalAxes_2_1',
                  'BinaryPrincipalAxes_2_2']
    
    def get_BinaryPrincipalAxes_0_0(self, value):
        return value.GetVnlMatrix().get(0,0)
    def get_BinaryPrincipalAxes_0_1(self, value):
        return value.GetVnlMatrix().get(0,1)
    def get_BinaryPrincipalAxes_0_2(self, value):
        return value.GetVnlMatrix().get(0,2)
    def get_BinaryPrincipalAxes_1_0(self, value):
        return value.GetVnlMatrix().get(1,0)
    def get_BinaryPrincipalAxes_1_1(self, value):
        return value.GetVnlMatrix().get(1,1)
    def get_BinaryPrincipalAxes_1_2(self, value):
        return value.GetVnlMatrix().get(1,2)
    def get_BinaryPrincipalAxes_2_0(self, value):
        return value.GetVnlMatrix().get(2,0)
    def get_BinaryPrincipalAxes_2_1(self, value):
        return value.GetVnlMatrix().get(2,1)
    def get_BinaryPrincipalAxes_2_2(self, value):
        return value.GetVnlMatrix().get(2,2)


class EquivalentEllipsoidSizeFilter(IDataFilter):

    original = 'EquivalentEllipsoidSize'
    new_values = ['EquivalentEllipsoidSize_X',
                  'EquivalentEllipsoidSize_Y',
                  'EquivalentEllipsoidSize_Z']
    
    def get_EquivalentEllipsoidSize_X (self, value):
        return value[0]
    def get_EquivalentEllipsoidSize_Y (self, value):
        return value[1]
    def get_EquivalentEllipsoidSize_Z (self, value):
        return value[2]
        
