# -*- coding: utf-8 -*-
'''
Created on 17/11/2009

@author: jmorales
'''

import itk

class Segmentation(object):
    '''
    This class is a wrapper of itk.LabelMap than makes easier the manipulation 
    and provides solution for some lacks of WrapItk like AttributeLabelObject
    
    @ivar labelmap: itkLabelMap
    @ivar segment_table: the table of object-segment :: {(int)object:(int)segment}
    @ivar select_table: the table of object-selected :: {(int)object:(bool)selected}
    '''
    image_type = itk.Image[itk.UC, 3]
    export_image_type = itk.Image[itk.US, 3]
    label_object_type = itk.StatisticsLabelObject[itk.UL, 3]
    labelmap_type = itk.LabelMap[label_object_type]

    def __init__(self):
        self.labelmap = None
        self.segment_table = {}
        self.select_table = {}
        self.inclusive_margins = [0,0,0]
        self.exclusive_margins = [0,0,0]

    def __nonzero__(self):
        '''Reimplemented the truth testing behavior'''
        return self.labelmap != None
    
    def __len__(self):
        return len(self.segment_table)

    def get_labels(self):
        return self.labelmap.GetLabels()
    
    def create_empty(self, origin, spacing, size):
        '''
        @param origin: [x,y,z]
        @param spacing: [x,y,z]
        @param size: [x,y,z]       
        '''
        print origin, spacing, size
        self.labelmap = itk.LabelMap[self.label_object_type].New()
        self.labelmap.SetOrigin(origin)
        self.labelmap.SetSpacing(spacing)
        self.labelmap.SetRegions(size)    
        
    def import_image_as_labelmap(self, image):
        ''' @warning: This method doesn't create the segment_table. 
        Creates labelmap from export_image_typed image.'''
        labelmap_filter = itk.LabelImageToShapeLabelMapFilter[self.export_image_type,
                                                              self.labelmap_type].New()
        labelmap_filter.SetInput(image)
        labelmap_filter.Update()
        self.labelmap = labelmap_filter.GetOutput()

    def create_from_labeled_image(self, image, segment=1):
        ''' Create labelmap from itkImage'''
        labelmap_filter = itk.LabelImageToShapeLabelMapFilter[self.export_image_type,
                                                              self.labelmap_type].New()
        labelmap_filter.SetInput(image)
        labelmap_filter.Update()
        self.labelmap = labelmap_filter.GetOutput()
        num_objects = self.labelmap.GetNumberOfLabelObjects()
        for label in range(1, num_objects +1):
            self.segment_table[label] = segment
            self.select_table[label] = True

    def create_from_binary_image(self, image, segment=1):

        labelmap_filter = itk.BinaryImageToShapeLabelMapFilter[self.image_type,
                                                              self.labelmap_type].New()
        labelmap_filter.SetInput(image)
        labelmap_filter.SetInputForegroundValue(1)
        labelmap_filter.Update()
        self.labelmap = labelmap_filter.GetOutput()
        # There is only one object in the labelmap
        self.segment_table[1] = segment
        self.select_table[1] = True
#        print '----------------------------------------------------------'
#        print 'numero:', self.labelmap.GetNumberOfLabelObjects()
#        self.labelmap.PrintLabelObjects()
#        print '----------------------------------------------------------'

    def add_binary_image(self, image, segment=1):
        labelmap_filter = itk.BinaryImageToShapeLabelMapFilter[self.image_type,
                                                               self.labelmap_type].New()
        labelmap_filter.SetInput(image)
        labelmap_filter.SetInputForegroundValue(1)
        labelmap_filter.Update()
        new_labelmap = labelmap_filter.GetOutput()
        
        new_object = new_labelmap.GetLabelObject(1)
        self.push_label_object(new_object, segment)
        

    def push_label_object(self, label_object, segment=1):
        ''' Add a label object to the labelmap with new label'''
        self.labelmap.PushLabelObject(label_object)
        
        label = label_object.GetLabel()        
        self.segment_table[label] = segment
        self.select_table[label] = True
        
    def remove_label(self, label):
        self.labelmap.RemoveLabel(label)

        self.segment_table.pop(label)
        self.select_table.pop(label)
    
    def get_spacing(self):
        spacing = self.labelmap.GetSpacing()
        return spacing[0], spacing[1], spacing[2]
    
    def get_pixel(self, i, j, k):
        index = [i, j, k]
        return self.labelmap.GetPixel(index)
    
    def is_selected(self, label):
        return self.select_table[label]
    
    def is_there_any_label(self, segment):
        return bool ([item[0] for item in self.segment_table.items() if item[1] == segment])        
    
    def get_segment(self, label):
        return self.segment_table[label]
    
    def get_selected(self, segment=None):
        if segment:
            labels_selected = [item[0] for item in self.segment_table.items() if item[1] == segment and self.select_table[item[0]]]
        else:
            labels_selected = [item[0] for item in self.select_table.items() if item[1]]
        return labels_selected
    
    def set_ubiased_brick_margins(self, inclusive_margins, exclusive_margins):
        self.inclusive_margins = inclusive_margins
        self.exclusive_margins = exclusive_margins
        
    #===========================================================================
    #       Attributes methods 
    #===========================================================================

    def update_attributes(self, feature_image, exhaustive=False):
        shape_filter = itk.ShapeLabelMapFilter[self.labelmap_type].New()
        shape_filter.SetInput(self.labelmap)
        if exhaustive:
            shape_filter.ComputeFeretDiameterOn()
            # TODO: The perimeter is not needed, But this must be chosen using a
            # preferences From.
            # shape_filter.ComputePerimeterOn()

        statistics_filter = itk.StatisticsLabelMapFilter[self.labelmap_type,
                                                         self.image_type].New()
        statistics_filter.SetFeatureImage(feature_image)
        statistics_filter.SetInput(shape_filter.GetOutput())
        self.labelmap = statistics_filter.GetOutput()

        statistics_filter.Update()
        
        #self.labelmap.PrintLabelObjects()

    def get_centroid(self, label):
        object = self.labelmap.GetLabelObject(label)
        return object.GetCentroid()

    #===========================================================================
    #       Transformation Filters 
    #===========================================================================
    def apply_unbiased_brick(self):
        '''
        This method filters the objects that:
            1- Are completely outside the margins
            2- Touch the exclusive margins
        @param inclusive_margins: [pixel_margin_X, pixel_margin_Y, pixel_margin_Z]  
        @param exclusive_margins: [pixel_margin_X, pixel_margin_Y, pixel_margin_Z]  
        '''
        inclusive_margins = self.inclusive_margins
        exclusive_margins = self.exclusive_margins
        #
        # Inclusive planes does not correspond with lower or upper planes
        #
        #    inclusive = [X1, X2, X3]        exclusive = [O1, O2, O3]
        #    lower = [X1, O2, O3]            upper = [O1, X2, X3]
        #
        lower_crop = [inclusive_margins[0] +1, exclusive_margins[1], exclusive_margins[2]]
        lower_pad = [inclusive_margins[0] +1, 0, 0]
        upper_crop = [exclusive_margins[0], inclusive_margins[1] +1, inclusive_margins[2] +1]
        upper_pad = [0, inclusive_margins[1] +1, inclusive_margins[2] +1]
        
        #
        # Crop the labelmap to feet the brick
        #
        croper = itk.CropLabelMapFilter[self.labelmap_type].New()
        croper.SetInPlace(False)
        croper.SetLowerBoundaryCropSize(lower_crop)
        croper.SetUpperBoundaryCropSize(upper_crop)
        croper.SetInput(self.labelmap)
        
        #
        # Pad out the labelmap in the direction of inclusive planes
        #
        pader = itk.PadLabelMapFilter[self.labelmap_type].New()
        pader.SetLowerBoundaryPadSize(lower_pad)
        pader.SetUpperBoundaryPadSize(upper_pad)
        pader.SetInput(croper.GetOutput())

        #
        # Update SizeOnBorder
        #
        shape_filter = itk.ShapeLabelMapFilter[self.labelmap_type].New()
        shape_filter.SetInput(pader.GetOutput())
        
        #
        # Filter the objects that touch any boundary
        #
        border_filter = itk.ShapeOpeningLabelMapFilter[self.labelmap_type].New()
        border_filter.SetInput(shape_filter.GetOutput())
        border_filter.SetAttribute('SizeOnBorder')
        border_filter.SetLambda(1)
        border_filter.ReverseOrderingOn()
        
        border_filter.Update()
        
        #
        # Unselect the excluded objects
        #
        all_objects = self.segment_table.keys()
        objects_inside = border_filter.GetOutput().GetLabels()
        objects_outside = set(all_objects).difference(objects_inside)
        for label in objects_outside:
            self.select_table[label] = False

    def filter_by_size(self, minimum, maximum=None, segment=1):
        min_filter = itk.ShapeOpeningLabelMapFilter[self.labelmap_type].New()
        min_filter.SetInput(self.labelmap)
        min_filter.SetAttribute('Size')
        min_filter.SetLambda(minimum)
        
        last_filter = min_filter
        if maximum:
            max_filter = itk.ShapeOpeningLabelMapFilter[self.labelmap_type].New()
            max_filter.SetInput(min_filter.GetOutput())
            max_filter.SetAttribute('Size')
            max_filter.SetLambda(maximum)
            max_filter.ReverseOrderingOn()
        
            last_filter = max_filter

        relabeler = itk.StatisticsRelabelLabelMapFilter[self.labelmap_type].New()
        relabeler.SetInput(last_filter.GetOutput())
        relabeler.SetAttribute('Size')

        self.labelmap = relabeler.GetOutput()
        relabeler.Update()

        labels = self.labelmap.GetLabels()
        self.segment_table = {}
        self.select_table = {}
        for label in labels:
            self.segment_table[label] = segment
            self.select_table[label] = True
    
    
    
    #===========================================================================
    #             Exports methods
    #===========================================================================
    
    def export_labelmap_as_image(self):
        image_converter = itk.LabelMapToLabelImageFilter[self.labelmap_type,
                                                         self.export_image_type].New()                                               
        image_converter.SetInput(self.labelmap)
        image_converter.Update()
        return image_converter.GetOutput()
    
    def get_segmented_image(self):
        ''' 
        This method returns an itkImage with segment values
        Filters the unselected objects
        '''
        change_map = {}
        for label in self.segment_table:
            change_map[label] = self.segment_table[label] if self.select_table[label] else 0
        
        changer = itk.ChangeLabelLabelMapFilter[self.labelmap_type].New()
        changer.SetInput(self.labelmap)
        changer.SetChangeMap(change_map)
        changer.SetInPlace(False)
        
        image_converter = itk.LabelMapToLabelImageFilter[self.labelmap_type,
                                                          self.image_type].New()
        image_converter.SetInput(changer.GetOutput())
        image_converter.Update()
        self.segmented_image = image_converter.GetOutput()

        #changer.GetOutput().PrintLabelObjects()
        #print 'despues changer', self.labelmap.GetNumberOfLabelObjects()
        #self.labelmap.PrintLabelObjects()
        return self.segmented_image
    
    def get_vtk_segmented_image(self):
        ''' This method returns a vtkImageData with segment values
            Warning: Make a deepcopy to use this output image
        '''
        # print 'vtkimage, number:', self.labelmap.GetNumberOfLabelObjects()
        #itk to vtk
        image_type = itk.Image[itk.UC, 3]
        itk_vtk_converter = itk.ImageToVTKImageFilter[image_type].New()
        itk_vtk_converter.SetInput(self.get_segmented_image())
        itk_vtk_converter.Update()
        self.vtk_segmented_image = itk_vtk_converter.GetOutput()

        return self.vtk_segmented_image 
    
    def get_object_data(self, label, attribute_names):
        ''' Returns a dictionary with the attributes requested
        @param attribute_names: [str] the names of the attributes requested
        @warning: The attributes migth be out of date.
        '''
        labelmap_object = self.labelmap.GetLabelObject(label)

        data = {}

        for attribute_name in attribute_names:
            value = labelmap_object.__getattribute__("Get"+attribute_name)()
            data[attribute_name] =  value
            
        return data
        
    def extract_object(self, label, crop=False):
        ''' This method returns an itkImage with only the requested object, cropped
            to the object region is optional
        '''
        object_region = self.labelmap.GetLabelObject(label).GetRegion()
    
        aux_labelmap = itk.LabelMap[self.label_object_type].New()
        aux_labelmap.CopyInformation(self.labelmap)
        aux_labelmap.AddLabelObject(self.labelmap.GetLabelObject(label))   
        
        image_converter = itk.LabelMapToLabelImageFilter[self.labelmap_type,
                                                         self.export_image_type].New()                                               
        image_converter.SetInput(aux_labelmap)
        image_converter.Update()
        
        if crop:
            roi = itk.RegionOfInterestImageFilter[self.export_image_type, self.export_image_type].New()
            roi.SetRegionOfInterest(object_region)
            roi.SetInput(image_converter.GetOutput())
            roi.Update()
    
            image = roi.GetOutput()
        else:
            image = image_converter.GetOutput()
        
        return image
        
    def is_integrity_okay(self):
        ''' Returns if all labels has any object associated in the labelmap '''
        return set(self.labelmap.GetLabels()) == set(self.segment_table.keys())
    
    def get_lables_not_in_the_segmentation(self):
        ''' Returns all the labels not having object associated in the labelmap '''
        return set(self.labelmap.GetLabels()).symmetric_difference(set(self.segment_table.keys()))
