'''
Created on 13/08/2009

@author: jmorales
'''
import vtk

class ImageViewerSlider(vtk.vtkImageViewer2):
    '''
    Change the behaveour of vtkImageViewer2
    '''
    
    rwi = None
    ia = None
    
    def SetInput(self, image_data):
        old_input = vtk.vtkImageViewer2.GetInput(self)
        if old_input:
            del old_input
        
        vtk.vtkImageViewer2.SetInput(self, image_data)
        self.ia = vtk.vtkImageViewer2.GetImageActor(self)
        self.ia.InterpolateOff()
        #vtk.vtkImageViewer2.GetRenderer(self).ResetCamera()

    def SetupInteractor(self, RenderWindoWInteractor):
        vtk.vtkImageViewer2.SetupInteractor(self, RenderWindoWInteractor)
        self.rwi = RenderWindoWInteractor
        self.style = vtk.vtkInteractorStyleImage()
        self.rwi.SetInteractorStyle(self.style)
        
        picker = vtk.vtkPropPicker()
        self.rwi.SetPicker(picker)
        
        self.style.AddObserver("MouseWheelForwardEvent", self.Slice)
        self.style.AddObserver("MouseWheelBackwardEvent", self.Slice)
        
    def Slice(self, o, e):
        actual_slice = vtk.vtkImageViewer2.GetSlice(self)
        forward = -1
        backward = +1
        if vtk.vtkImageViewer2.GetSliceOrientation(self) == 2:
            forward, backward = backward, forward
        if e == "MouseWheelForwardEvent":
            self.SetSlice(actual_slice + forward)
        if e == "MouseWheelBackwardEvent":
            self.SetSlice(actual_slice + backward)
        
    def SetSlice(self, slice):
        max_slice = self.ia.GetSliceNumberMax()
        min_slice = self.ia.GetSliceNumberMin()
        
        new_slice = max (min_slice, min (max_slice, slice))
        vtk.vtkImageViewer2.SetSlice(self, new_slice)
        vtk.vtkImageViewer2.Render(self)
        return new_slice
    
    def GetSliceNumberMax(self):
        return self.ia.GetSliceNumberMax()
        
    def GetSliceNumberMin(self):
        return self.ia.GetSliceNumberMin()