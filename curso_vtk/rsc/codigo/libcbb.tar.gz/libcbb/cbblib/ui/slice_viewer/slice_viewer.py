# -*- coding: utf-8 -*-
'''
Created on 30/09/2010

@author: jmorales
'''

from PyQt4 import QtCore, QtGui
import vtk

from ui_slide_widget import Ui_Form
import lib_cbb.lib_util.conversion as conversion


class SlideWidget(QtGui.QWidget, Ui_Form):
    def __init__(self, parent):
        QtGui.QWidget.__init__(self, parent)
        # Setup the UI
        self.setupUi(self)
        
        # self.slider.setInvertedAppearance(True)
        self.slider.setInvertedControls(True)
        self.number.setReadOnly(True)
        self.converter = conversion.SliceNumberConverter()

        self.connect(self.slider, QtCore.SIGNAL('valueChanged(int)'), self.scroll_changed)
        #self.connect(self.slider, QtCore.SIGNAL('sliderMoved(int)'), self.scroll_changed)
        #self.connect(self.number, QtCore.SIGNAL('textEdited(QString)'), self.number_changed)
        
        self.image_viewer.style.AddObserver("MouseWheelForwardEvent", self.slice_changed)
        self.image_viewer.style.AddObserver("MouseWheelBackwardEvent", self.slice_changed)
        
        #
        # Geting the event from style insted from rwi avoid the sandard style response. (ctrl -> rotate, etc)
        # self.image_viewer.rwi.AddObserver("LeftButtonPressEvent", self.on_pick)
        self.image_viewer.style.AddObserver("LeftButtonPressEvent", self.on_pick)
        
        self.connect(self, QtCore.SIGNAL('slice_changed(int)'), self.on_slice_changed)
        self.crosshairs = None
        
    def set_background(self, r, g, b):
        ''' 0 <= r,g,b <= 1'''
        self.image_viewer.GetRenderer().SetBackground(r,g,b)
        self.image_viewer.Render()
    
    def add_volume(self, volume):
        self.image_viewer.SetInput(volume)
        self.converter.volume_extent = volume.GetExtent()
        self.set_ranges()
        self.image_viewer.Render()
        
    def initialize(self):
        if self.crosshairs:
            self.remove_cursor()
            
        if self.image_viewer.GetSliceOrientation() == 2:
            slice = self.image_viewer.GetSliceNumberMax()
        else:
            slice = self.image_viewer.GetSliceNumberMin()
        self.show_slice(slice)
        self.image_viewer.GetRenderer().ResetCamera()
        self.image_viewer.Render()
        
    def set_ranges(self):
        min = self.image_viewer.GetSliceNumberMin()
        max = self.image_viewer.GetSliceNumberMax()
        if self.image_viewer.GetSliceOrientation() == 2:
            min += conversion.offset 
            max += conversion.offset
        self.slider.setRange(min, max)
        
    def set_orientation_to_xy(self):
        self.image_viewer.SetSliceOrientationToXY()
        self.set_ranges()
        self._set_slice(self.image_viewer.GetSliceNumberMin())
 
    def set_orientation_to_xz(self):
        self.image_viewer.SetSliceOrientationToXZ()
        self.set_ranges()
        self._set_slice(self.image_viewer.GetSliceNumberMin())
        
    def set_orientation_to_yz(self):
        self.image_viewer.SetSliceOrientationToYZ()
        self.image_viewer.GetRenderer().GetActiveCamera().Roll(90)
        self.set_ranges()
        self._set_slice(self.image_viewer.GetSliceNumberMin())
        
    def show_slice(self, slice):
        ''' Show the slice in the viewer, the slider and the number'''
        slice = self._set_slice(slice)
        self.display_slice_number(slice)
        self.set_slider_value(slice)
        return slice
    
    def _set_slice(self, slice):
        slice = self.image_viewer.SetSlice(slice)
        self.emit(QtCore.SIGNAL('slice_changed(int)'), slice)
        return slice
    
    def set_cursor(self, i, j, k):
        ''' Show the slice that contains the point and draws a crosshair in that point'''
        self.last_pick = [i, j, k]
        volume = self.image_viewer.GetInput()
        sx, sy, sz = volume.GetSpacing()
        point = [int (i/sx), int(j/sy), int(k/sz)] 
        
        camera_axis = self.image_viewer.GetSliceOrientation()
        # Set slice
        slice = point[camera_axis]
        
        
        self._off_screen_rendering_update(slice)    
        
        #vtk.vtkMapper.SetResolveCoincidentTopologyToPolygonOffset()
        #vtk.vtkMapper.SetResolveCoincidentTopologyPolygonOffsetParameters(10,10)
        
        self.show_slice(slice)
        self._create_crosshair([i, j, k])
        self.image_viewer.Render()

    # TODO: Probar SetDisplayLocationToBackground 
    def _off_screen_rendering_update(self, slice):
        # FIXME: Para que se muestren los actores se debe de haber repintado 
        # el slice justo antes de añadirlos... para que no se note el guiño se 
        # renderiza fuera de la pantalla. 
        self.image_viewer.OffScreenRenderingOn()
        self.image_viewer.SetSlice(slice -1)
        self.image_viewer.SetSlice(slice +1)
        self.image_viewer.OffScreenRenderingOff()
    
    def _create_crosshair(self, point):
        ''' Create an actor that represents a crosshair '''
        volume = self.image_viewer.GetInput()
        spacing = list(volume.GetSpacing())
        points = vtk.vtkPoints()
        lines = vtk.vtkCellArray()
        current_point = 0
        extent = list(volume.GetExtent())
        
        for axis in range(3):
            point1 = []
            point2 = []
            point1.extend(point)
            point2.extend(point)
            point1[axis] = extent[axis * 2] * spacing[axis]
            point2[axis] = extent[(axis * 2) +1] * spacing[axis]
            
            #print "point1", point1
            #print "point2", point2
            
            points.InsertNextPoint(point1)
            points.InsertNextPoint(point2)
            lines.InsertNextCell(2)
            lines.InsertCellPoint(current_point)
            lines.InsertCellPoint(current_point + 1)
            current_point+=2
        polyData = vtk.vtkPolyData()
        polyData.SetPoints(points)
        polyData.SetLines(lines)
        # Set up a transform to move the crosshair closer to the camera
        movement = [0, 0, 0]
        camera_axis = self.image_viewer.GetSliceOrientation()
        movement[camera_axis] = 1 if camera_axis != 1 else -1
        transform = vtk.vtkTransform()
        transform.Identity()
        transform.Translate(movement)
        
        transform_filter = vtk.vtkTransformPolyDataFilter()
        transform_filter.SetTransform(transform)
        transform_filter.SetInput(polyData)
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(transform_filter.GetOutputPort())
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor([0, 0, 1])
        actor.GetProperty().SetOpacity(1)
        actor.GetProperty().SetLineWidth(1)
        actor.SetPickable(0)
        
        renderer = self.image_viewer.GetRenderer()
        renderer.AddActor(actor)
        self.crosshairs = actor
        
    def remove_cursor(self, slice=None):
        if self.crosshairs:
            renderer = self.image_viewer.GetRenderer()
            renderer.RemoveActor(self.crosshairs)
            self.crosshairs = None
            
    def display_slice_number(self, intern_slice):
        if self.image_viewer.GetSliceOrientation() == 2:
            self.number.setText(str(self.converter.convert(intern_slice)))
        else:
            self.number.setText(str(intern_slice))
            
    def get_slider_value(self):
        if self.image_viewer.GetSliceOrientation() == 2:
            return self.converter.convert(self.slider.value()) 
        else:
            return self.slider.value()
        
    def set_slider_value(self, value):
        if self.image_viewer.GetSliceOrientation() == 2:
            self.slider.setValue(self.converter.convert(value))
        else:
            self.slider.setValue(value)
        
    #===========================================================================
    #      Events Handlers
    #===========================================================================
    def slice_changed(self, emisor, event):
        ''' When MouseWheelForward/Backward is emited'''
        self.display_slice_number(self.image_viewer.GetSlice())
        self.set_slider_value(self.image_viewer.GetSlice())
        self.emit(QtCore.SIGNAL('slice_changed(int)'), self.image_viewer.GetSlice())
        
    def scroll_changed(self, _slice):
        ''' When valueChanged(int) is emited'''
        slice = self.get_slider_value()
        self.display_slice_number(slice)
        self._set_slice(slice)
        
    def number_changed(self, str_slice):
        ''' When textEdited(str) is emited'''
        if str(str_slice) == '':
            str_slice = '0'
        if str(str_slice).isdigit():
            slice = self._set_slice(int(str_slice))
            self.set_slider_value(int(slice))
        else:
            self.display_slice_number(self.image_viewer.GetSlice())
            
    def on_pick(self, rwi_or_rwis, event):
        ''' When LeftButtonPressEvent is emited'''
        rwi = self.image_viewer.rwi
        x, y = rwi.GetEventPosition()
        picker = rwi.GetPicker()
        if picker.PickProp(x, y, self.image_viewer.GetRenderer()):
            volume = picker.GetViewProp().GetInput()
            i, j , k = volume.GetPoint(volume.FindPoint(picker.GetPickPosition()))
            sx, sy, sz = volume.GetSpacing()
            if rwi.GetControlKey():
                self.emit(QtCore.SIGNAL('control_picked'), i, j, k)
            else:
                self.emit(QtCore.SIGNAL('picked'), int (i/sx), int(j/sy), int(k/sz))
                self.emit(QtCore.SIGNAL('world_picked'), i, j, k)

    def on_slice_changed(self, slice=None):
        ''' When slice_changed(int) is emited'''
        self.remove_cursor(slice)
        self.image_viewer.Render()

