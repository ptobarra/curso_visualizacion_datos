# -*- coding: utf-8 -*-
'''
Created on 27/05/2010

@author: jmorales
'''

from PyQt4 import QtGui, QtCore

class MainWindow(QtGui.QMainWindow):
    def __init__(self, *args):
        QtGui.QMainWindow.__init__(self, *args)
        self.resize(1024, 768)


    def menu(self, object_name, title=None):
        ''' Returns the menu with the provided object_name. If the menu does not
         exist, a new one is created and added to the menu bar
         
         TODO: implement a weight system to order menus
         '''
        menu_bar = self.menuBar()
        menu = menu_bar.findChild(QtGui.QMenu, object_name)
        if not menu:
            # Create the menu
            menu = QtGui.QMenu(menu_bar)
            menu.setObjectName(object_name)
            title = object_name if not title else title
            menu.setTitle(title)
            menu_bar.addMenu(menu)
        return menu
        
        
#    def createPopupMenu(self):
#        ''' Right-clicking on a toolbar or a dock widget will not show the 
#            visibility menu.
#            
#            Overloaded method
#        '''
#        return None
    

            
