# -*- coding: utf-8 -*-
'''
Created on 04/03/2011

@author: jmorales
'''

from slice_viewer.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
from PyQt4 import QtCore
import vtk
import abc

class Stage(object):
    
    def __init__(self, parent):
        ''' 
        @ivar actors: {'name':vtkActor} All the actors that are already computed.
                                        Those actors are not necessary in the renderer. 
        '''
        self.actors = {}
        
        self.rwi = QVTKRenderWindowInteractor(parent)
        self.rwi.setMinimumSize(QtCore.QSize(10,10))
        self.rwi.SetInteractorStyle(vtk.vtkInteractorStyleTrackballCamera())        
        self.rwi.Initialize()
        
        self.rw = self.rwi.GetRenderWindow() # render_window

    def add_actors(self, actors):
        updated_actors = []
        for actor_name in actors:
            actor = self.actors.get(actor_name, None)
            if actor != None and actor != actors[actor_name]:
                updated_actors.append(self.actors[actor_name])
            self.actors[actor_name] = actors[actor_name]
        return updated_actors
        
    def create_renderer(self, position="center", backgroud=(0.1, 0.2, 0.4)):
        '''
        @var position: [center, up, down, left, right]
        '''
        renderer = vtk.vtkRenderer()
        #renderer.SetBackground(backgroud)
        if position == "center":
            pass
        elif position == "down":
            renderer.SetViewport(0, 0, 1.0, 0.5)
        elif position == "up":
            renderer.SetViewport(0, 0.5, 1.0, 1.0)        
        elif position == "left":
            renderer.SetViewport(0, 0, 0.5, 1.0)
        elif position == "right":
            renderer.SetViewport(0.5, 0, 1.0, 1.0)        
        
        ligths = vtk.vtkLightKit()
        ligths.AddLightsToRenderer(renderer)
        self.rw.AddRenderer(renderer)
        self.rwi.Render()
        
        return renderer

    def remove_renderer(self, renderer):
        renderer.RemoveAllViewProps()
        self.rw.RemoveRenderer(renderer)
        
    def remove_actor(self, actor_name):
        self.actors.pop(actor_name)
    
    def remove_actors(self):
        self.actors.clear()
    
    def remove_actors_by_prefix(self, prefix):
        '''@var prefix: str '''
        for actor_name in self.actors.keys():
            if actor_name.startswith(prefix):
                self.actors.pop(actor_name)
    
    def clear(self):
        self.actors.clear()
        renderer_collection = self.rw.GetRenderers()
        for _i in range(renderer_collection.GetNumberOfItems()):
            r = renderer_collection.GetNextItem()
            self.rw.RemoveRenderer(r)

class Scene(object):

    __metaclass__ = abc.ABCMeta
    def __init__(self,  stage, prefix=''):
        self.stage = stage
        self.name = ''
        self.actor_names = set()  # The names of the actors involved in this stage
        self.modified = False
        self.renderer = None
        self.prefix = prefix
        
        self.actors_visibility={} #{"actor_name":bool}

    def set_renderer(self, renderer):
        self.renderer = renderer

    def _actors_not_in_stage(self):
        ''' This method finds actors that have already been created in the
         stage to not re-create them if it's not necessary. '''
        actors_in_stage = set(self.stage.actors.keys())
        return self.actor_names.difference(actors_in_stage)

    def show(self):
        updated_actors = self.stage.add_actors(self.get_actors())
        for a in updated_actors:
            self.renderer.RemoveActor(a)
            
        actors = self.stage.actors
        for n in self.actor_names:
            if actors.has_key(n): 
                if self.actors_visibility.get(n, True):
                    self.renderer.AddActor(actors[n])
                else:
                    self.renderer.RemoveActor(actors[n])
        self.stage.rw.Render()

    @abc.abstractmethod
    def get_actors(self):
        '''  
        @return: {"name":vtkActor} to include them in the stage
        '''
