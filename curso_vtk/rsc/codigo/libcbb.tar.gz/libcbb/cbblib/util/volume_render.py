# -*- coding: utf-8 -*-
'''
Created on 16/02/2011

@author: jmorales
'''
import vtk

class VolumertricRender(object):
    def __init__(self, renderer, labelmap, lut, visible=True):
        '''
        renderer = vtkRenderer
        labelmap = vtkImageData
        lut = LookupTable
        '''
        self.renderer = renderer
        self.labelmap = labelmap
        self.lut = lut
        self.visible = visible

        self._create_volume_pipeline()

    def update_labelmap(self, labelmap):
        self.labelmap = labelmap
        self.volume_mapper.SetInput(self.labelmap)
        self.update_render()
    
    def update_lut(self, lut):
        self.lut = lut
        self.volume_properties.SetColor(self.lut.get_as_vtkColorTransferFunction())
        self.update_render()
    
    def show(self):
        self.visible = True
        if self.volume:
            self.renderer.AddVolume(self.volume)
            self.update_render()

    def hide(self):
        self.visible = False
        if self.volume:
            self.renderer.RemoveVolume(self.volume)
            self.update_render()

    def _create_volume_pipeline(self):
        self.volume_mapper = vtk.vtkVolumeRayCastMapper()
        self.ray_cast_function = vtk.vtkVolumeRayCastCompositeFunction()
        self.volume_mapper.SetVolumeRayCastFunction(self.ray_cast_function)
        
        #self.volume_mapper = vtk.vtkFixedPointVolumeRayCastMapper()
        #self.volume_mapper = vtk.vtkVolumeTextureMapper3D()
        #self.volume_mapper = vtk.vtkVolumeTextureMapper2D()
        
        self.volume_mapper.SetInput(self.labelmap) 
    
        self.opacity_transfer_func = vtk.vtkPiecewiseFunction()
        self.opacity_transfer_func.AddPoint(0, 0.0)
        self.opacity_transfer_func.AddPoint(1, 1)
        
        self.volume_properties = vtk.vtkVolumeProperty()
        self.volume_properties.SetColor(self.lut.get_as_vtkColorTransferFunction())
        self.volume_properties.SetScalarOpacity(self.opacity_transfer_func)

        self.volume_properties.ShadeOn()
        self.volume_properties.SetInterpolationTypeToNearest()

        self.volume = vtk.vtkVolume()
        self.volume.SetMapper(self.volume_mapper)
        self.volume.SetProperty(self.volume_properties)
            
        if self.visible:
            self.renderer.AddVolume(self.volume)
            self.update_render()
            
    def update_render(self):
        self.renderer.Update()