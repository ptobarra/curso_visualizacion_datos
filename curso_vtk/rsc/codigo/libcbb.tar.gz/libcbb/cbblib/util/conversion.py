# -*- coding: utf-8 -*-
'''
Created on 04/02/2010
@author: jmorales
'''
# The 0 slice is convert to offset slice 
offset = 1
class SliceNumberConverter(object):
    '''
    The slice number in z axes is inverted. The internal slice 0 is the 
    external slice 1.
    
    This class manages this conversion.
    
    The conversions is reversible: 
               external =  max - internal + min
               internal = max - external + min
               
    Son only one function is needed
    '''
    def __init__(self, volume_extent=None):
        self.volume_extent = volume_extent
        
    def convert (self, slice):
        if not self.volume_extent:
            return slice
        min, max = self.volume_extent[-2:]
        return max - slice + min + offset
    
