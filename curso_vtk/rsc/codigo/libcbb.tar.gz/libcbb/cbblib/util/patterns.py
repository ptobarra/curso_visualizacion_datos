'''
Created on 21/03/2011

@author: crispamares
'''

class Observer(object):
    '''
    GOF observer pattern
    '''
    def __init__(self):
        self.observers = {} 
            
    def add_observer(self, event, callable):
        if self.observers.has_key(event):
            self.observers[event].append(callable)
        else:
            self.observers[event] = [callable]
            
    def remove_observer(self, event, callable):
        self.observers[event].remove(callable)
        
    def remove_observer_if_exist(self, event, callable):
        try:
            self.remove_observer(event, callable)
        except ValueError:
            pass
        
    def remove_observers(self, event):
        self.observers.pop(event)
    
    def clear_observers(self):
        self.observers.clear()
    
    def _notify(self, event, *args):
        if self.observers.has_key(event):
            for callable in self.observers[event]:
                if not args:
                    callable()
                else:
                    callable(*args)
        