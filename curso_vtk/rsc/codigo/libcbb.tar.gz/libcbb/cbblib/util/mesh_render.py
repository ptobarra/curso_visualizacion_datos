# -*- coding: utf-8 -*-
'''
Created on 16/02/2011

@author: jmorales
'''

import vtk
            
class MeshRender(object):
    def __init__(self, renderer, labelmap, lut, visible=True):
        '''
        renderer = vtkRenderer
        labelmap = vtkImageData
        lut = LookupTable
        '''
        self.renderer = renderer
        self.labelmap = labelmap
        self.lut = lut
        self.visible = visible
        
        # For shrinking the labelmap
        # TODO: move to config
        self.shrink = False
        self.canonic_volume_vol = 700 * 600 * 100
        
        self.actors = []

    def update_labelmap(self, labelmap):
        self.labelmap = labelmap
        self.update_render()
    
    def update_lut(self, lut):
        self.lut = lut
        self.update_render()
    
    def show(self):
        self.visible = True
        if self.actors:
            for actor in self.actors:
                self.renderer.AddActor(actor)
            self.update_render()
            
    def hide(self):
        self.visible = False
        if self.actors:
            self.remove_actors_from_render()
            self.update_render()
    
    def render(self):
        if self.actors:
            self.remove_actors_from_render()
            self.actors = []
        
        lut = self.lut.get_as_description()
        for segment in lut:
            name, r, g, b = lut[segment]
            self.render_segment(segment, r/255.0, g/255.0, b/255.0)
    
        if self.visible:
            self.update_render()

    def remove_actors_from_render(self):
        for actor in self.actors:
                self.renderer.RemoveActor(actor)
        
    def render_segment(self, segment, r, g, b):

        threshold = vtk.vtkImageThreshold()
        threshold.SetInput(self.labelmap)
        threshold.SetOutValue(0)
        threshold.SetInValue(255)
        #threshold.ThresholdByUpper(1)
        threshold.ThresholdBetween(segment, segment)
        threshold.ReleaseDataFlagOn()
        threshold.Update()
        
        _minimmum, maximmum = threshold.GetOutput().GetScalarRange()
        if maximmum == 0.0:
            return
        
        if self.shrink:
            volume_vol = (self.labelmap.GetDimensions()[0] * 
                          self.labelmap.GetDimensions()[1] * 
                          self.labelmap.GetDimensions()[2])
    
            shrink_factor = max(1, (volume_vol / self.canonic_volume_vol)/3)
            print "***shrink_factor", shrink_factor
            
            shrinker = vtk.vtkImageShrink3D()
            shrinker.SetInput(threshold.GetOutput())
            shrinker.SetShrinkFactors(shrink_factor, shrink_factor, shrink_factor)
            shrinker.AveragingOn()
            shrinker.ReleaseDataFlagOn()
        
        
        gauss = vtk.vtkImageGaussianSmooth()
        gauss.SetDimensionality(3)
        gauss.SetStandardDeviation(1.5, 1.5, 1)
        gauss.SetRadiusFactor(1)
        if self.shrink:
            gauss.SetInput(shrinker.GetOutput())
        else:
            gauss.SetInput(threshold.GetOutput())
        gauss.ReleaseDataFlagOn()

        contour = vtk.vtkMarchingCubes()
        contour.ComputeScalarsOff()
        contour.ComputeGradientsOff()
        contour.ComputeNormalsOff()
        contour.SetInput(gauss.GetOutput())
        contour.SetValue(0, 127.5)
        contour.ReleaseDataFlagOn()
        
        decimator = vtk.vtkDecimatePro()
        decimator.SetInput(contour.GetOutput())
        decimator.SetFeatureAngle(60)
        decimator.PreserveTopologyOn()
        decimator.SetTargetReduction(0.5)
        decimator.ReleaseDataFlagOn()
        
        smoother = vtk.vtkSmoothPolyDataFilter()
        smoother.SetInput(decimator.GetOutput())
        smoother.SetNumberOfIterations(0)
        smoother.SetRelaxationFactor(0.01)
        smoother.SetFeatureAngle(60)
        smoother.FeatureEdgeSmoothingOn()
        smoother.BoundarySmoothingOff()
        smoother.SetConvergence(0)
        smoother.ReleaseDataFlagOn()
        
        normals = vtk.vtkPolyDataNormals()
        normals.SetInput(smoother.GetOutput())
        normals.SetFeatureAngle(60)
        normals.ReleaseDataFlagOn()
        
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInput(normals.GetOutput())
    
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        
        actor.GetProperty().SetDiffuseColor(r, g, b)
        actor.GetProperty().SetSpecularPower(80)
        actor.GetProperty().SetSpecular(0.5)
        actor.GetProperty().SetDiffuse(1)

        self.renderer.AddActor(actor)
        self.actors.append(actor)
                    
    def update_render(self):
        self.renderer.Render()
        
