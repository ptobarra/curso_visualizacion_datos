# -*- coding: utf-8 -*-
'''
Created on 30/09/2010

@author: jmorales
'''
import itk

IT_UC = itk.Image[itk.UC, 3]
IT_US = itk.Image[itk.US, 3]
IT_F = itk.Image[itk.F, 3]
