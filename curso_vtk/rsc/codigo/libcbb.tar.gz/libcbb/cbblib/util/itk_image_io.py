# -*- coding: utf-8 -*-
'''
Created on 30/09/2010

@author: jmorales
'''
import itk

''' This module provides common operations related with the IO of itk images.

The image managed are itk.Image
'''

def itk_read_image(file_name, pixel_type):
    '''@var pixel_type: One of the types defined at itk_types'''
    reader = itk.ImageFileReader[pixel_type].New()
    reader.SetFileName(file_name)
    reader.SetImageIO(itk.MetaImageIO.New())
    reader.Update()
    
    return reader.GetOutput()

def itk_write_image(file_name, image_to_write, pixel_type):
    '''@var pixel_type: One of the types defined at itk_types
    @var image_to_write: itk.Image 
    '''
    writer = itk.ImageFileWriter[pixel_type].New()
    writer.SetFileName(file_name)
    writer.SetInput(image_to_write)
    writer.Update()

