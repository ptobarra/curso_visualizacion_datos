# -*- coding: utf-8 -*-
'''
Created on 13/03/2012

@author: jmorales
'''
import vtk

def vtk_read_image(file_name, change_direction=True):
    reader = vtk.vtkMetaImageReader()
    reader.SetFileName(file_name)
    reader.Update()

    last_filter = reader
    
    if change_direction:
        reslicer = vtk.vtkImageReslice()
        reslicer.SetResliceAxesDirectionCosines(1, 0, 0, 0, -1, 0, 0, 0, -1)
        reslicer.SetInput(reader.GetOutput())
        
        change_information = vtk.vtkImageChangeInformation()
        change_information.SetInput(reslicer.GetOutput())
        change_information.SetInformationInput(reader.GetOutput())
        change_information.Update()
        
        last_filter = change_information

#    volume = vtk.vtkImageData()
#    volume.DeepCopy(last_filter.GetOutput())
#    volume.Update()

    return last_filter.GetOutput()#volume