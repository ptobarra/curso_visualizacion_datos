# -*- coding: utf-8 -*-
'''
Created on 16/02/2011

@author: jmorales
'''
from cbblib.tad.labelmap import multy_mesh, segmha_io
import vtk
import os, sys
import json

from multiprocessing.pool import ThreadPool


class MultyMeshExporter(object):
    def __init__(self, dir, segmha):
        self.dir = dir
        self.segmha = segmha
        self.segmentation = None
        self.lut = None
        self.actors = {}

    def load_segmentation(self, file_name):
        reader = segmha_io.SegmentationMetaImageReader()
        self.segmentation , self.lut = reader.read(file_name)
    
    def create_dir(self, dir):
        os.mkdir(dir)
    
    def compute_actors(self, segmentation, lut):
        mesh_renderer = multy_mesh.MultyMeshFilter(segmentation, lut)
        actors = mesh_renderer.compute_actors()
        self.actors = dict(map(lambda x: (str(x[0]),x[1]), actors.items()))
        return self.actors

    def write_actors_json(self, actors):
        actors_out = []
        for name in actors:
            actor = {}
            actor['name'] = name
            actor['color'] = actors[name].GetProperty().GetDiffuseColor()
            actor['path'] = name+'.vtk'
            actors_out.append(actor)
        with open(os.path.join(self.dir,'actors.json'), 'w') as f:
            f.write(json.dumps(actors_out, indent=2))

    def write_actors(self, actors, binary=False):
        writer = vtk.vtkPolyDataWriter()
        if binary:
            writer.SetFileTypeToBinary()
        for name in actors:
            print >> sys.stderr, 'To write', name
            actor = actors[name]
            poly_data = actor.GetMapper().GetInput()
            writer.SetFileName(os.path.join(self.dir, name+'.vtk'))
            writer.SetInput(poly_data)
            try:
                writer.Write()
            except:
                print >> sys.stderr, '**************** FAILED:', name

    def run(self):
        self.create_dir(self.dir)
        self.load_segmentation(self.segmha)
        self.compute_actors(self.segmentation, self.lut)
        self.write_actors_json(self.actors)
        self.write_actors(self.actors)



class MultyMeshLoader(object):
    def __init__(self, dir):
        self.dir = dir
        self.actor_list = []
        self.actors = {}
        
    def read_actors_json(self):
        with open(os.path.join(self.dir, 'actors.json'), 'r') as f:
            self.actor_list = json.loads(f.read())
        
    def read_poly_data(self, file_name):
        reader = vtk.vtkPolyDataReader()
        reader.SetFileName(file_name)
        reader.Update()
        return reader.GetOutput()
        
    def _read_actor(self, actor_info):
        poly_data = self.read_poly_data(os.path.join(self.dir, actor_info['path']))
            
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInput(poly_data)

        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        
        actor.GetProperty().SetDiffuseColor(actor_info['color'])
        actor.GetProperty().SetSpecularPower(80)
        actor.GetProperty().SetSpecular(0.5)
        actor.GetProperty().SetDiffuse(1) 
        return actor_info['name'], actor

    def read_actors(self, actor_list):
        for actor_info in actor_list:
            name, actor = self._read_actor(actor_info)
            self.actors[name] = actor

    def parallel_read_actors(self, actor_list):
        pool = ThreadPool()
        result = pool.map(self._read_actor, actor_list)
        self.actors = dict(result)
        
    def run(self, parallel=True):
        self.read_actors_json()
        if parallel:
            self.parallel_read_actors(self.actor_list)
        else:
            self.read_actors(self.actor_list)
        return self.actors


if __name__ == '__main__':
    print 'Exporting...'
    grande = '/home/crispamares/proyectos/workspace/synapses/synapses/data/layers/w33-10-L2-1-008-270-033x.segmha'
    peque = '/media/42895d7a-c866-4755-ad71-9ef53cf4542e/crispamares/facultad/tesis/sets/Serie2_electronico/02 JPGs_Stack_affine_crop_239-353/stacks/peque234.segmha'
    exporter = MultyMeshExporter('/tmp/pedo',grande)
    exporter.run()
    print "------- READING ----------"
    loader = MultyMeshLoader('/tmp/pedo')
    print loader.run(parallel=True)